/**
 * meta-collector.js — runs at document_idle on every page.
 * Reads og/meta tags from the already-parsed DOM and caches the result
 * in chrome.storage.session keyed by URL. The popup reads this instantly
 * on open with no extraction latency.
 */
(function () {
  function getMeta(...selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      const v = el?.getAttribute('content') || el?.getAttribute('datetime') || '';
      if (v.trim()) return v.trim();
    }
    return '';
  }

  const data = {
    thumbnail:   getMeta('meta[property="og:image"]', 'meta[name="twitter:image"]'),
    description: getMeta('meta[property="og:description"]', 'meta[name="description"]', 'meta[name="twitter:description"]'),
    siteName:    getMeta('meta[property="og:site_name"]'),
    author:      getMeta('meta[name="author"]', 'meta[property="article:author"]'),
    publishedDate: getMeta('meta[property="article:published_time"]', 'time[datetime]'),
  };

  // Only cache if we got something useful
  if (data.thumbnail || data.description || data.siteName) {
    chrome.storage.session.set({ [location.href]: data });
  }
})();
